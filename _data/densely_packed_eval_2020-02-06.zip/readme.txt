
This file contains the evaluation code for the densely packed products detection challenge in CVPR 2020.

To evaluate your results use the demo.py file by specifying the local path to the ground-truth annotations as well as the path to your detections file. Your detections file should be a CSV with the following columns: image_name,x1,y1,x2,y2,confidence (do not include the column names in your file, the first row should be the first detection). For example, see the file "example_results.csv" or the file "Goldman_etal_SKU110_test_results.csv" that is available in the challenge website.


